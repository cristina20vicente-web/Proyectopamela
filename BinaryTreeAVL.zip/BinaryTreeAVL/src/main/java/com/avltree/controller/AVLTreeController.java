package com.avltree.controller;

import com.avltree.model.Node;
import com.avltree.model.Animal;
import com.avltree.service.AVLTree;
import com.avltree.service.TreePersistenceService;
import com.avltree.util.TreeVisualizer;
import java.util.List;
import java.util.Scanner;

/**
 * Controlador principal que maneja el menú de la aplicación para árbol AVL de Animales
 */
public class AVLTreeController {
    private final AVLTree<Animal> tree;
    private final TreePersistenceService<Animal> persistenceService;
    private final Scanner scanner;

    public AVLTreeController() {
        this.tree = new AVLTree<>();
        this.scanner = new Scanner(System.in);
        this.persistenceService = new TreePersistenceService<>(tree, Animal.class);
    }

    /**
     * Método principal que ejecuta la aplicación
     */
    public void run() {
        showWelcomeMessage();

        try {
            System.out.println("🔄 Sincronizando datos existentes...");
            persistenceService.syncWithDatabase();
            System.out.println("✅ Datos sincronizados correctamente");
        } catch (Exception e) {
            System.out.println("⚠ Error al sincronizar datos: " + e.getMessage());
            System.out.println("Continuando con árbol vacío...");
        }

        boolean running = true;
        while (running) {
            showMainMenu();
            int option = getIntInput("Seleccione una opción: ");

            switch (option) {
                case 1:
                 insertAnimal();
                case 2:
                 updateAnimal();
                case 3:
                 searchAnimal();
                case 4:
                deleteAnimal();
                case 5:
                graphTree();
                case 6:
                databaseMenu();
                case 7:
                showTreeInfo();
                case 8:
                showAllAnimals();
                case 0:
                {
                    running = false;
                    shutdown();
                }
                default:
                System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }

            if (running) {
                System.out.println("\nPresione Enter para continuar...");
                scanner.nextLine();
            }
        }
    }

    private void showWelcomeMessage() {
        System.out.println("╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║             ÁRBOL AVL DE ANIMALES CON MONGODB               ║");
        System.out.println("║       Gestión de Animales ordenados por código único        ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝");
        System.out.println();
    }

    private void showMainMenu() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("                    MENÚ PRINCIPAL");
        System.out.println("=".repeat(60));
        System.out.println("1. Insertar animal");
        System.out.println("2. Actualizar animal");
        System.out.println("3. Buscar animal por código");
        System.out.println("4. Eliminar animal");
        System.out.println("5. Graficar árbol");
        System.out.println("6. Operaciones de base de datos");
        System.out.println("7. Información del árbol");
        System.out.println("8. Mostrar todos los animales");
        System.out.println("0. Salir");
        System.out.println("=".repeat(60));
    }

    private void insertAnimal() {
        System.out.println("\n=== INSERTAR ANIMAL ===");

        try {
            String codigo = getStringInput("Ingrese el código del animal: ");
            String nombreComun = getStringInput("Ingrese el nombre común: ");
            String especie = getStringInput("Ingrese la especie: ");
            int edad = getIntInput("Ingrese la edad: ");

            Animal animal = new Animal(nombreComun, especie, edad, codigo);

            if (!animal.isValid()) {
                System.out.println("Datos del animal inválidos. Verifique que:");
                System.out.println("   - Nombre común y especie no estén vacíos");
                System.out.println("   - Edad esté entre 1 y 149 años");
                System.out.println("   - Código tenga al menos 4 caracteres");
                return;
            }

            tree.insert(animal);
            System.out.println("✓ Animal insertado exitosamente");
            System.out.println("✓ " + animal.getDetalle());

            Node<Animal> insertedNode = tree.search(animal);
            if (insertedNode != null) {
                persistenceService.saveNode(insertedNode);
            }

        } catch (Exception e) {
            System.out.println("Error al insertar el animal: " + e.getMessage());
        }
    }

    private void updateAnimal() {
        System.out.println("\n=== ACTUALIZAR ANIMAL ===");

        if (tree.isEmpty()) {
            System.out.println("⚠ El árbol está vacío");
            return;
        }

        try {
            String codigo = getStringInput("Ingrese el código del animal a actualizar: ");
            Animal searchAnimal = new Animal("", "", 0, codigo);
            Node<Animal> node = tree.search(searchAnimal);

            if (node == null) {
                System.out.println("❌ No se encontró un animal con el código " + codigo);
                return;
            }

            Animal currentAnimal = node.getData();
            System.out.println("Animal actual: " + currentAnimal.getDetalle());
            System.out.println();

            System.out.println("Ingrese los nuevos datos (Enter para mantener el valor actual):");

            String nuevoNombre = getStringInputOptional("Nuevo nombre común [" + currentAnimal.getNombreComun() + "]: ");
            if (nuevoNombre.isEmpty()) nuevoNombre = currentAnimal.getNombreComun();

            String nuevaEspecie = getStringInputOptional("Nueva especie [" + currentAnimal.getEspecie() + "]: ");
            if (nuevaEspecie.isEmpty()) nuevaEspecie = currentAnimal.getEspecie();

            String edadStr = getStringInputOptional("Nueva edad [" + currentAnimal.getEdad() + "]: ");
            int nuevaEdad = currentAnimal.getEdad();
            if (!edadStr.isEmpty()) {
                try {
                    nuevaEdad = Integer.parseInt(edadStr);
                } catch (NumberFormatException e) {
                    System.out.println("❌ Edad inválida, se mantiene valor actual");
                }
            }

            String nuevoCodigo = getStringInputOptional("Nuevo código [" + currentAnimal.getCodigo() + "]: ");
            if (nuevoCodigo.isEmpty()) nuevoCodigo = currentAnimal.getCodigo();

            Animal nuevoAnimal = new Animal(nuevoNombre, nuevaEspecie, nuevaEdad, nuevoCodigo);

            if (!nuevoAnimal.isValid()) {
                System.out.println("❌ Los nuevos datos son inválidos");
                return;
            }

            boolean updated = tree.update(currentAnimal, nuevoAnimal);
            if (updated) {
                System.out.println("✓ Animal actualizado exitosamente");
                System.out.println("✓ " + nuevoAnimal.getDetalle());

                Node<Animal> updatedNode = tree.search(nuevoAnimal);
                if (updatedNode != null) {
                    persistenceService.saveNode(updatedNode);
                }
            } else {
                System.out.println("❌ No se pudo actualizar el animal");
            }

        } catch (Exception e) {
            System.out.println("❌ Error al actualizar el animal: " + e.getMessage());
        }
    }

    private void searchAnimal() {
        System.out.println("\n=== BUSCAR ANIMAL ===");

        if (tree.isEmpty()) {
            System.out.println("⚠ El árbol está vacío");
            return;
        }

        try {
            String codigo = getStringInput("Ingrese el código a buscar: ");
            Animal searchAnimal = new Animal("", "", 0, codigo);
            Node<Animal> node = tree.search(searchAnimal);

            if (node != null) {
                Animal animal = node.getData();
                System.out.println("✓ Animal encontrado:");
                System.out.println("  " + animal.getDetalle());
                System.out.println("  Altura en árbol: " + node.getHeight());
            } else {
                System.out.println("❌ No se encontró un animal con el código " + codigo);
            }

        } catch (Exception e) {
            System.out.println("❌ Error al buscar el animal: " + e.getMessage());
        }
    }

    private void deleteAnimal() {
        System.out.println("\n=== ELIMINAR ANIMAL ===");

        if (tree.isEmpty()) {
            System.out.println("⚠ El árbol está vacío");
            return;
        }

        try {
            String codigo = getStringInput("Ingrese el código del animal a eliminar: ");
            Animal searchAnimal = new Animal("", "", 0, codigo);
            Node<Animal> node = tree.search(searchAnimal);

            if (node == null) {
                System.out.println("❌ No se encontró un animal con el código " + codigo);
                return;
            }

            Animal animal = node.getData();
            System.out.println("Animal a eliminar: " + animal.getDetalle());
            String confirm = getStringInput("¿Está seguro? (s/n): ");

            if (confirm.toLowerCase().startsWith("s")) {
                tree.delete(animal);
                System.out.println("✓ Animal eliminado exitosamente");
                persistenceService.deleteNode(animal);
            } else {
                System.out.println("Operación cancelada");
            }

        } catch (Exception e) {
            System.out.println("❌ Error al eliminar el animal: " + e.getMessage());
        }
    }

    private void graphTree() {
        System.out.println("\n=== GRAFICAR ÁRBOL ===");

        if (tree.isEmpty()) {
            System.out.println("⚠ El árbol está vacío");
            return;
        }

        boolean showingGraph = true;
        while (showingGraph) {
            TreeVisualizer.showVisualizationMenu(tree.getRoot());
            int option = getIntInput("Seleccione una opción: ");

            if (option == 0) {
                showingGraph = false;
            } else {
                TreeVisualizer.executeVisualization(tree.getRoot(), option);
                if (option != 4) {
                    System.out.println("\nPresione Enter para continuar...");
                    scanner.nextLine();
                }
            }
        }
    }

    private void showAllAnimals() {
        System.out.println("\n=== TODOS LOS ANIMALES (ORDENADOS POR CÓDIGO) ===");

        if (tree.isEmpty()) {
            System.out.println("⚠ No hay animales registrados");
            return;
        }

        List<Node<Animal>> nodes = tree.inorderTraversal();
        System.out.println("Total de animales: " + nodes.size());
        System.out.println();

        int count = 1;
        for (Node<Animal> node : nodes) {
            Animal animal = node.getData();
            System.out.printf("%3d. %s%n", count++, animal.getDetalle());
        }
    }

    private void databaseMenu() {
        boolean inDatabaseMenu = true;

        while (inDatabaseMenu) {
            System.out.println("\n=== OPERACIONES DE BASE DE DATOS ===");
            System.out.println("1. Guardar árbol completo");
            System.out.println("2. Cargar árbol desde BD");
            System.out.println("3. Sincronizar con BD");
            System.out.println("4. Estadísticas de BD");
            System.out.println("5. Verificar integridad");
            System.out.println("6. Limpiar base de datos");
            System.out.println("0. Regresar");

            int option = getIntInput("Seleccione una opción: ");

            switch (option) {
                case 1:
                persistenceService.saveTree();
                case 2:
                persistenceService.loadTree();
                case 3:
                persistenceService.syncWithDatabase();
                case 4:
                persistenceService.printDatabaseStats();
                case 5:
            persistenceService.verifyIntegrity();
                case 6:
                {
                    String confirm = getStringInput("¿Está seguro de limpiar la BD? (s/n): ");
                    if (confirm.toLowerCase().startsWith("s")) {
                        persistenceService.clearDatabase();
                    }
                }
                case 0:
                inDatabaseMenu = false;
                default:
                System.out.println("❌ Opción no válida");
            }

            if (inDatabaseMenu && option != 0) {
                System.out.println("\nPresione Enter para continuar...");
                scanner.nextLine();
            }
        }
    }

    private void showTreeInfo() {
        System.out.println("\n=== INFORMACIÓN DEL ÁRBOL ===");

        if (tree.isEmpty()) {
            System.out.println("⚠ El árbol está vacío");
        } else {
            TreeVisualizer.printTreeInfo(tree.getRoot());
        }
    }

    private void shutdown() {
        System.out.println("\n=== CERRANDO APLICACIÓN ===");

        try {
            if (!tree.isEmpty()) {
                String save = getStringInput("¿Desea guardar los cambios en la base de datos? (s/n): ");
                if (save.toLowerCase().startsWith("s")) {
                    persistenceService.saveTree();
                }
            }

            System.out.println("¡Gracias por usar el sistema de Gestión de Animales con Árbol AVL!");

        } catch (Exception e) {
            System.out.println("Error durante el cierre: " + e.getMessage());
        } finally {
            // No se cierra el scanner para evitar errores de System.in
        }
    }

    private int getIntInput(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                String input = scanner.nextLine().trim();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("❌ Por favor, ingrese un número válido.");
            }
        }
    }

    private String getStringInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private String getStringInputOptional(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }
}
