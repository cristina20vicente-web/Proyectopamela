package com.avltree.model;

import java.io.Serializable;

/**
 * Clase que representa un Animal dentro del árbol AVL
 */
public class Animal implements Comparable<Animal>, Serializable {
    private String nombreComun;
    private String especie;
    private int edad;
    private String codigo; // identificador único

    public Animal(String nombreComun, String especie, int edad, String codigo) {
        this.nombreComun = nombreComun;
        this.especie = especie;
        this.edad = edad;
        this.codigo = codigo;
    }

    public String getNombreComun() {
        return nombreComun;
    }

    public void setNombreComun(String nombreComun) {
        this.nombreComun = nombreComun;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * Validación básica de los datos del animal
     */
    public boolean isValid() {
        return nombreComun != null && !nombreComun.isBlank()
                && especie != null && !especie.isBlank()
                && edad > 0 && edad < 150
                && codigo != null && codigo.length() >= 4;
    }

    /**
     * Detalle descriptivo del animal
     */
    public String getDetalle() {
        return String.format("Código: %s | Nombre común: %s | Especie: %s | Edad: %d años",
                codigo, nombreComun, especie, edad);
    }

    /**
     * Comparación basada en el código del animal (orden en el árbol AVL)
     */
    @Override
    public int compareTo(Animal otro) {
        if (otro == null || otro.codigo == null) return 1;
        return this.codigo.compareToIgnoreCase(otro.codigo);
    }

    @Override
    public String toString() {
        return getDetalle();
    }
}
