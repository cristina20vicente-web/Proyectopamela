# 🦁 Ejemplos de Especies para Probar el Árbol AVL

Este archivo contiene ejemplos de **especies animales** que puedes usar para probar el funcionamiento de tu **Árbol AVL**.  
El propósito es verificar que el árbol se mantenga **balanceado**, que las operaciones de **búsqueda**, **actualización** y **eliminación** funcionen correctamente,  
y que la organización por **código de especie** sea la esperada.

---

## 🐾 Datos de Ejemplo

### Especie 1
- **Nombre común:** Perro
- **Nombre científico:** *Canis lupus familiaris*
- **Promedio de vida:** 13 años
- **Código de especie:** 1001

### Especie 2
- **Nombre común:** Gato
- **Nombre científico:** *Felis catus*
- **Promedio de vida:** 15 años
- **Código de especie:** 1002

### Especie 3
- **Nombre común:** Caballo
- **Nombre científico:** *Equus ferus caballus*
- **Promedio de vida:** 25 años
- **Código de especie:** 1003

### Especie 4
- **Nombre común:** Conejo
- **Nombre científico:** *Oryctolagus cuniculus*
- **Promedio de vida:** 9 años
- **Código de especie:** 1004

### Especie 5
- **Nombre común:** Elefante
- **Nombre científico:** *Loxodonta africana*
- **Promedio de vida:** 60 años
- **Código de especie:** 1005

### Especie 6
- **Nombre común:** León
- **Nombre científico:** *Panthera leo*
- **Promedio de vida:** 14 años
- **Código de especie:** 1006

### Especie 7
- **Nombre común:** Tigre
- **Nombre científico:** *Panthera tigris*
- **Promedio de vida:** 20 años
- **Código de especie:** 1007

### Especie 8
- **Nombre común:** Delfín
- **Nombre científico:** *Delphinus delphis*
- **Promedio de vida:** 30 años
- **Código de especie:** 1008

---

## 🌿 Orden Esperado en el Árbol (por Código de Especie)

Cuando insertes estas especies, el árbol AVL las ordenará automáticamente según su **Código de especie**:

1. 1001 - Perro (*Canis lupus familiaris*)
2. 1002 - Gato (*Felis catus*)
3. 1003 - Caballo (*Equus ferus caballus*)
4. 1004 - Conejo (*Oryctolagus cuniculus*)
5. 1005 - Elefante (*Loxodonta africana*)
6. 1006 - León (*Panthera leo*)
7. 1007 - Tigre (*Panthera tigris*)
8. 1008 - Delfín (*Delphinus delphis*)

---

## 🔍 Pruebas Recomendadas

### 1. Inserción Secuencial
Inserta las especies en el orden mostrado arriba para observar cómo el **Árbol AVL** se equilibra automáticamente.

### 2. Inserción Aleatoria
Inserta las especies en un orden aleatorio para visualizar las **rotaciones AVL** (rotación simple y doble).

### 3. Búsquedas
- Buscar una especie existente (por ejemplo: código `1001` → Perro).
- Buscar una especie inexistente (por ejemplo: código `9999`).

### 4. Actualizaciones
- Cambia el promedio de vida del **León** a 16 años.
- Modifica el nombre científico del **Tigre** a *Panthera tigris altaica*.

### 5. Eliminaciones
- Elimina una especie sin descendencia (por ejemplo, una hoja).
- Elimina una especie con un solo descendiente.
- Elimina una especie con dos descendientes (para probar el balance del árbol).

### 6. Visualización del Árbol
Después de cada operación (inserción, eliminación, actualización), genera el **gráfico del árbol** para ver:
- La estructura jerárquica (nodos e hijos).
- El recorrido *inorder* (de menor a mayor código).
- Los factores de balance y la altura de cada nodo.

---

## ⚙️ Validaciones del Sistema

El sistema debe garantizar:
- Nombres comunes y científicos no vacíos.
- Promedio de vida entre **1 y 200 años**.
- Código de especie numérico de al menos **4 dígitos**.
- No se permiten **códigos repetidos** (si existe, se actualiza la especie).

---

## 🐘 Extensiones del Proyecto

Si tu aplicación lo permite, puedes agregar funcionalidades como:
- Registrar el **hábitat natural** o **zona geográfica** de cada especie.
- Guardar las especies en una **base de datos** (por ejemplo, MongoDB Atlas).
- Exportar o importar el árbol completo.
- Mostrar estadísticas como el número total de especies, altura del árbol o nivel de balance.

---

¡Disfruta probando tu Árbol AVL de especies animales! 🐾